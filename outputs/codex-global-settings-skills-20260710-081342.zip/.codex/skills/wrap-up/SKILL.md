---
name: wrap-up
description: End-of-work closeout workflow for Codex. Use when the user says 收工, 下班, 結束, wrap up, finish up, close out, summarize work, or asks Codex to complete a session by reviewing actual changes, verification results, unresolved risks, and next steps before giving a concise final report.
---

# Wrap Up

## Core Rule

Close the work with evidence, not memory. Review what actually changed, what was actually verified, and what still needs attention before reporting completion.

## Closeout Checklist

1. Re-read the newest user request and confirm the report answers that request, not an older task.
2. Identify the intended completion standard from the request and project instructions.
3. Review actual work performed in this session using deterministic evidence when available: changed files, command output, tests, generated artifacts, or tool results.
4. Check whether verification was run and whether it passed, failed, or was only partial.
5. Check for unresolved risks, assumptions, skipped work, inaccessible files, failed commands, or decisions still needed from the user.
6. Keep the final report concise and useful.

## Closeout Flow

Use this sequence when finishing code, document, project, or analysis work:

1. Inspect: confirm changed files, produced artifacts, and relevant command results.
2. Verify: run or review the most relevant deterministic checks available.
3. Resolve: fix small issues found during closeout when they are clearly within scope.
4. Report: summarize what changed, how it was verified, and any remaining risks.

## Completion Report

Use this structure unless the user requests another format:

1. 修改了什麼
2. 如何驗證
3. 尚有哪些風險或未完成事項

## Guardrails

- Do not say work is complete unless the requested outcome is actually complete.
- Do not say tests passed unless tests were actually run and passed.
- If no files were changed, say so.
- If verification was not run, failed, or was partial, state that plainly.
- If the task was analysis-only, summarize the conclusion and evidence instead of inventing a change list.
- Relay important command output directly when the user needs it.
- Match the user's language. If the user writes Chinese, report in Traditional Chinese.