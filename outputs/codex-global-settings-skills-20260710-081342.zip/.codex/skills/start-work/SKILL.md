---
name: start-work
description: Start-of-work kickoff workflow for Codex. Use when the user says 開工, 開始, start work, kickoff, resume work, or asks Codex to begin a task and the agent should clarify the goal, read the right project context, define success criteria, choose a minimal plan, and decide how completion will be verified before making changes.
---

# Start Work

## Core Rule

Start by creating a clear working frame before editing files or running broad changes. Keep the frame lightweight for small tasks and explicit for multi-step or risky tasks.

## Kickoff Checklist

1. Restate the task goal in one sentence when the request has more than one reasonable interpretation.
2. Identify constraints, success criteria, and what "done" means.
3. Read relevant local instructions first, especially `AGENTS.md`, project docs, target files, direct callers, shared helpers, and existing tests.
4. Ask a concise question only when missing information would make a reasonable assumption risky.
5. Prefer the smallest change that satisfies the current goal.
6. Define the verification method before finishing: tests, build, lint, manual inspection, generated artifact review, or a clear reason verification is not possible.

## Working Flow

Use this sequence for code or project work:

1. Inspect: gather only the context needed for the request.
2. Decide: state the intended approach if the task is multi-step, risky, or ambiguous.
3. Execute: make precise changes limited to the requested behavior.
4. Verify: run the most relevant deterministic checks available.
5. Report: summarize what changed, how it was verified, and any remaining risks.

## Checkpoints

For multi-step work, give short progress updates after meaningful milestones:

- what was completed
- what was verified
- what is next
- any uncertainty or risk

If the task grows beyond the current context or becomes unstable, stop and summarize the state before continuing.

## Guardrails

- Do not invent architecture, product direction, or broad abstractions unless the user asked for them.
- Do not modify unrelated files, formatting, names, or comments.
- Do not hide partial work, failed checks, skipped tests, inaccessible files, or assumptions.
- Do not claim completion until the requested outcome is implemented and verification has been run or explicitly explained.
